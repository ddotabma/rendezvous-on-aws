def handler(_, __):
    print('hi')
    return "OK!"